public class Foo {
	
	public static int returnOne() {
		return 1;
	}

}
