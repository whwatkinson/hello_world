// compiled by 880-compile-sharp.cobra
class Hello {
	public static void Main() {
		System.Console.WriteLine("Hello - C# compiled by Cobra");
	}
}
