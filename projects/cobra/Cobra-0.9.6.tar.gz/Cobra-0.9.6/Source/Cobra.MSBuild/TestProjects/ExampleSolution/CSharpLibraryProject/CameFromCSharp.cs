using System;

namespace CSharpLibraryProject
{
	public class CameFromCSharp
	{
		public CameFromCSharp ()
		{
		}
	}
}

