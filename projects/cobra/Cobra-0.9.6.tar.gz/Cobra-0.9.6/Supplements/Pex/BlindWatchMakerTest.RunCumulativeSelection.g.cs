namespace TestProject1
{
	public partial class BlindWatchMakerTest
	{
	}
}
