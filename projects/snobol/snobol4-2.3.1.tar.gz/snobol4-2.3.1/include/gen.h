/* $Id: gen.h,v 1.2 2020-09-27 19:45:56 phil Exp $ */

/* prototypes for generated functions */

/* from data_init.c */
void init_data(void);

/* from syn.c */
void init_syntab(void);
