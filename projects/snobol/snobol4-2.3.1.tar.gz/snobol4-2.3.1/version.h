/*
 * generated Thu Mar 31 16:01:07 EDT 2022
 * on mail.ultimate.com (FreeBSD)
 * by $Id: configure,v 1.429 2022-03-31 19:58:27 phil Exp $
 */

#define VERSION "2.3.1"
#define VERSION_DATE "March 31, 2022"
