/* $Id: mdata.h,v 1.1 1993-12-28 15:39:28 budd Exp $ */

/* empty file for "COPY MDATA" */
