/* $Id: environ.c,v 1.2 2002-02-05 17:51:00 phil Exp $ */

/* not needed (obviously), but forces remake when re-configured */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H defined */

char **environ;
