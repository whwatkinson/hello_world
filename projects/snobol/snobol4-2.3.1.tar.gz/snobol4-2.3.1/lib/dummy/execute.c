/* $Id: execute.c,v 1.1 1996-10-24 03:34:23 phil Exp $ */

void
execute(buf)
    char *buf;
{
}
