/* $Id: getdtablesize.c,v 1.2 2020-09-29 06:01:40 phil Exp $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H defined */

#include <stdio.h>			/* for lib.h */

#include "h.h"
#include "snotypes.h"
#include "lib.h"

int
getdtablesize(void) {
    return 1024;
}
