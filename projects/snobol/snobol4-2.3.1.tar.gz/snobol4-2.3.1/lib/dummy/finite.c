/* $Id: finite.c,v 1.1 1998-02-15 05:29:07 phil Exp $ */

int
finite(x)
    double x;
{
    return 1;
}
