/* $Id: spcint.c,v 1.8 2020-11-19 02:31:31 phil Exp $ */

/*
 * convert from strings to long long using ad hoc code
 * for environments without long long library support
 * slower than system provided functions
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H defined */

#include <stdio.h>			/* for lib.h */
#include <ctype.h>

#include "h.h"
#include "snotypes.h"
#include "macros.h"
#include "lib.h"
#include "str.h"

#include "equ.h"			/* for I and R */
#include "res.h"
#include "data.h"

int
spcint(struct descr *dp, struct spec *sp) {
    size_t len;
    char *cp;
    int_t temp;
    int signum;

    len = S_L(sp);
    cp = S_SP(sp);

    if (D_A(SPITCL)) {			/* SPITBOL features? */
	/* strip leading whitespace */
	while (len > 0 && (*cp == ' ' || *cp == '\t')) {
	    cp++;
	    len--;
	}
    }

    temp = 0;
    signum = 1;
    if (*cp == '-') {
	signum = -1;
	cp++;
    }

    while (len > 0) {
	if (!isdigit((unsigned char)*cp))
	    return FALSE;
	temp *= 10;
	/* could just multiply... nah! */
	if (signum > 0)
	    temp += *cp - '0';
	else
	    temp -= *cp - '0';
	cp++;
	len--;
    }

    D_A(dp) = temp;
    D_F(dp) = 0;			/* clear flags */
    D_V(dp) = I;			/* set type */

    return TRUE;			/* success */
}
