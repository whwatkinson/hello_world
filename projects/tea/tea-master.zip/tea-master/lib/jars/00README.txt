This directory will contain all the JARs required by command line
tools.

All the JARs contained here are copied to this directory as part of
the build process.

This readme file is not included in the tarbal package.


