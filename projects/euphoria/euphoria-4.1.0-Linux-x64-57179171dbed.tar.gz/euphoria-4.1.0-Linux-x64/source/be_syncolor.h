#ifndef BE_SYNCOLOR_H_
#define BE_SYNCOLOR_H_

extern int syncolor;

void init_class();
int DisplayColorLine(char *pline, int string_color, int last_multi);
void set_syncolor(object);

#endif
