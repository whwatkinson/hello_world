#ifndef BE_MAIN_H_
#define BE_MAIN_H_

void be_init();

#endif
