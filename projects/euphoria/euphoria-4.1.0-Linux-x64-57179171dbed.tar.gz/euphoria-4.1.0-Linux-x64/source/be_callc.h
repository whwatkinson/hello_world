#ifndef BE_CALLC_H_
#define BE_CALLC_H_

#include "execute.h"

object call_c(int func, object proc_ad, object arg_list);

#endif
