include std/text.e as text

puts(1,"pipe_sub.ex: read from STDIN: '" & text:trim(gets(0)) & "'")
