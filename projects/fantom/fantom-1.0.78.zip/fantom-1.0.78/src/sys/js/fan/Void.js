//
// Copyright (c) 2009, Brian Frank and Andy Frank
// Licensed under the Academic Free License version 3.0
//
// History:
//   3 Dec 09 Andy Frank  Creation
//

/**
 * Void
 */
fan.sys.Void = function() {};
fan.sys.Void.prototype.$typeof = function() { return fan.sys.Void.$type; }

