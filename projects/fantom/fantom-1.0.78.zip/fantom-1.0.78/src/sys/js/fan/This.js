//
// Copyright (c) 2010, Brian Frank and Andy Frank
// Licensed under the Academic Free License version 3.0
//
// History:
//   15 Mar 10  Andy Frank  Creation
//

/**
 * This.
 */
fan.sys.This = fan.sys.Obj.$extend(fan.sys.Obj);

fan.sys.This.prototype.$ctor = function() {}
fan.sys.This.prototype.$typeof = function() { return fan.sys.This.$type; }

