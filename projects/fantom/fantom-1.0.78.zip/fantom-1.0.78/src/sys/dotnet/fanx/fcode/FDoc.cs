//
// Copyright (c) 2008, Brian Frank and Andy Frank
// Licensed under the Academic Free License version 3.0
//
// History:
//   18 Feb 08  Andy Frank  Creation
//

using System.IO;
using System.Text;
using Fan.Sys;

namespace Fanx.Fcode
{
  public class FDoc
  {
    public static void read(Stream input, object top)
    {
      // TODO: this code needs to be updated to use new
      // apidoc format introduced in 1.0.60 Sept 2011
    }
  }
}